package org.proyecto_pro2024.Util;
public enum Eleccion {
    TIJERAS, PAPEL, PIEDRA, LAGARTO, SPOCK
}
